// Placeholder firebase-config.js
// This file is a harmless stub so imports succeed while you iterate.
// Replace with your real Firebase initialization when ready.

console.warn('firebase-config stub loaded — replace with real config to enable auth');

export const auth = null;
export default {};
