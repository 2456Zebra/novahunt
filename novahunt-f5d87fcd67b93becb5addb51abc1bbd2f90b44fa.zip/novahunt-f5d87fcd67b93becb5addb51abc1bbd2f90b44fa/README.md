# NovaHunt

Force redeploy trigger — small README update to ensure Vercel picks up files and publishes the latest build.
